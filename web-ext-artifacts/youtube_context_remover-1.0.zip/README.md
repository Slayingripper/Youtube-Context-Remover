# Youtube Context Remover

# Description

Youtube decided to include the "context" box under descriptions in their videos. Although I understand that it might have good intentions, I don't want to see it. It sometimes creates a false sense of trust between the viewer and the youtube channel or completly the opposite. Although context always matters, The context box is not always relevant. 
This plugin removes the context box from videos when loaded. It'S simple script and it's free and opensource.





